:mod:`xor`
==========

.. module:: king_phisher.xor
   :synopsis:

This module provides basic support for XOR encoding and decoding operations.

Functions
---------

.. autofunction:: xor_decode

.. autofunction:: xor_encode
