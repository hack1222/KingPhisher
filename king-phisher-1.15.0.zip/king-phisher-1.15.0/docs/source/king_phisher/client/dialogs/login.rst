:mod:`login`
============

.. module:: king_phisher.client.dialogs.login
   :synopsis:

Classes
-------

.. autoclass:: LoginDialogBase
   :show-inheritance:
   :members:
   :special-members: __init__

.. autoclass:: LoginDialog
   :show-inheritance:
   :members:
   :special-members: __init__

.. autoclass:: SMTPLoginDialog
   :show-inheritance:
   :members:

.. autoclass:: SSHLoginDialog
   :show-inheritance:
   :members:
