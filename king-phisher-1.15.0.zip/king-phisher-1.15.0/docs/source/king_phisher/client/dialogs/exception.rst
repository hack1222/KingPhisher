:mod:`exception`
================

.. module:: king_phisher.client.dialogs.exception
   :synopsis:

Functions
---------

.. autofunction:: format_exception_details

.. autofunction:: format_exception_name

Classes
-------

.. autoclass:: ExceptionDialog
   :show-inheritance:
   :members:
   :special-members: __init__
