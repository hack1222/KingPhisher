:mod:`entry`
====================

.. module:: king_phisher.client.dialogs.entry
   :synopsis:

Classes
-------

.. autoclass:: TextEntryDialog
   :show-inheritance:
   :members:
   :special-members: __init__
