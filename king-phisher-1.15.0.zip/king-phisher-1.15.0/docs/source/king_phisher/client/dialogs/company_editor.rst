:mod:`company_editor`
=====================

.. module:: king_phisher.client.dialogs.company_editor
   :synopsis:

Classes
-------

.. autoclass:: CompanyEditorDialog
   :show-inheritance:
   :members:
