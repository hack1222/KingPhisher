:mod:`clone_page`
=================

.. module:: king_phisher.client.dialogs.clone_page
   :synopsis:

Classes
-------

.. autoclass:: ClonePageDialog
   :show-inheritance:
   :members:
   :special-members: __init__
