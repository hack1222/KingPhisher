:mod:`campaign_selection`
=========================

.. module:: king_phisher.client.dialogs.campaign_selection
   :synopsis:

Classes
-------

.. autoclass:: CampaignSelectionDialog
   :show-inheritance:
   :members:
   :special-members: __init__
