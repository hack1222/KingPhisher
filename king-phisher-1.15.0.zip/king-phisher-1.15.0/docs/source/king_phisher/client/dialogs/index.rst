:mod:`dialogs`
==============

.. module:: king_phisher.client.dialogs

.. toctree::
   :maxdepth: 2
   :titlesonly:

   about.rst
   campaign_selection.rst
   clone_page.rst
   company_editor.rst
   configuration.rst
   entry.rst
   exception.rst
   login.rst
   ssh_host_key.rst
   tag_editor.rst
