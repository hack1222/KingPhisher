:mod:`about`
============

.. module:: king_phisher.client.dialogs.about
   :synopsis:

Classes
-------

.. autoclass:: AboutDialog
   :show-inheritance:
   :members:
   :special-members: __init__
