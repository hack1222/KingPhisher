:mod:`tag_editor`
=================

.. module:: king_phisher.client.dialogs.tag_editor
   :synopsis:

Classes
-------

.. autoclass:: TagEditorDialog
   :show-inheritance:
   :members:
