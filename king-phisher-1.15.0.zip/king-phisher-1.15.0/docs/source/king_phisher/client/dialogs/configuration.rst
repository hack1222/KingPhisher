:mod:`configuration`
====================

.. module:: king_phisher.client.dialogs.configuration
   :synopsis:

Classes
-------

.. autoclass:: ConfigurationDialog
   :show-inheritance:
   :members:
   :special-members: __init__
