:mod:`widget`
=============

.. module:: king_phisher.client.widget

.. toctree::
   :maxdepth: 2
   :titlesonly:

   extras.rst
   managers.rst
   resources.rst
   completion_providers.rst
