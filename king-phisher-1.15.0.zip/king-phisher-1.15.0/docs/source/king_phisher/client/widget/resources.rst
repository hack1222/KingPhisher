:mod:`resources`
================

.. module:: king_phisher.client.widget.resources
   :synopsis:

This module contains resources useful to GTK widgets.

Data
----

.. autodata:: font_desc_italic
   :annotation:

.. autodata:: renderer_text_desc
   :annotation:

Classes
-------

.. autoclass:: CompanyEditorGrid
   :show-inheritance:
   :members:
   :special-members: __init__
