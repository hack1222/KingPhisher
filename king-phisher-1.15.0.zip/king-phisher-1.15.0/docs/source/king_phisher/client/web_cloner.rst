:mod:`web_cloner`
=================

.. module:: king_phisher.client.web_cloner
   :synopsis:

This module contains the functionality used by the client to clone web pages.

Classes
-------

.. autoclass:: ClonedResourceDetails
   :members:

.. autoclass:: WebPageCloner
   :show-inheritance:
   :members:
   :special-members: __init__
