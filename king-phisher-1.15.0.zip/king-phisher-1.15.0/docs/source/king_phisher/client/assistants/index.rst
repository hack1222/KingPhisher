:mod:`assistants`
=================

.. module:: king_phisher.client.assistants

.. toctree::
   :maxdepth: 2
   :titlesonly:

   campaign.rst
