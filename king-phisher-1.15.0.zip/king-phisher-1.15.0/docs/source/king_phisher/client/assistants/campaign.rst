:mod:`campaign`
===============

.. module:: king_phisher.client.assistants.campaign
   :synopsis:

Classes
-------

.. autoclass:: CampaignAssistant
   :show-inheritance:
   :members:
   :special-members: __init__
