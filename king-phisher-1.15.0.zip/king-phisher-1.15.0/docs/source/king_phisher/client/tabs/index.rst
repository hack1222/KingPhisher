:mod:`tabs`
===========

.. module:: king_phisher.client.tabs

This package contains modules for providing the content of the top level tabs
used by the main application window.

.. toctree::
   :maxdepth: 2
   :titlesonly:

   campaign.rst
   mail.rst
