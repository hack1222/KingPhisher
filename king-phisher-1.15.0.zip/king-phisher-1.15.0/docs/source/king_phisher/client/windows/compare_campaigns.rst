:mod:`compare_campaigns`
========================

.. module:: king_phisher.client.windows.compare_campaigns
   :synopsis:

This module provides the window through which the user can compare campaigns
across multiple data points in graph format

Classes
-------

.. autoclass:: CampaignCompWindow
   :show-inheritance:
   :members:
   :special-members: __init__
