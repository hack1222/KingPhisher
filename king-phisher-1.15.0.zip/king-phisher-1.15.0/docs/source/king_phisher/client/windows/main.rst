:mod:`main`
===========

.. module:: king_phisher.client.windows.main
   :synopsis:

This module provides the main window used by the client application.

Classes
-------

.. autoclass:: MainAppWindow
   :show-inheritance:
   :members:
   :special-members: __init__

.. autoclass:: MainMenuBar
   :show-inheritance:
   :members:
   :special-members: __init__
