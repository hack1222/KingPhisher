:mod:`campaign_import`
======================

.. module:: king_phisher.client.windows.campaign_import
   :synopsis:

This module provides the window through which the user can import King Phisher
campaigns from xml files previously exported with the
:py:mod:`~client.export` module.

Classes
-------

.. autoclass:: ImportCampaignWindow
   :show-inheritance:
   :members:
   :special-members: __init__
