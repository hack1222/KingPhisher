:mod:`html`
===========

.. module:: king_phisher.client.windows.html
   :synopsis:

This module provides a window which shows HTML content.


Classes
-------

.. autoclass:: HTMLWindow
   :show-inheritance:
   :members:
   :special-members: __init__
