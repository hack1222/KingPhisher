:mod:`ua_parser`
================

.. module:: king_phisher.ua_parser
   :synopsis:

This module provides functionality for parsing browser user agents to extract
information from them.

Functions
---------

.. autofunction:: parse_user_agent

Classes
-------

.. autoclass:: UserAgent
   :members:
