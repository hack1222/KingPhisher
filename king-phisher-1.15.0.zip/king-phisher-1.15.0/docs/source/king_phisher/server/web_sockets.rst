:mod:`web_sockets`
==================

.. module:: king_phisher.server.web_sockets
   :synopsis:

Classes
-------

.. autoclass:: Event
   :show-inheritance:
   :members:
   :special-members: __init__

.. autoclass:: EventSocket
   :show-inheritance:
   :members:
   :special-members: __init__

.. autoclass:: WebSocketsManager
   :show-inheritance:
   :members:
   :special-members: __init__
   :undoc-members:
