:mod:`plugins`
==============

.. module:: king_phisher.server.plugins
   :synopsis:

Classes
-------

.. autoclass:: ServerPlugin
   :show-inheritance:
   :members:

.. autoclass:: ServerPluginManager
   :show-inheritance:
   :members:
