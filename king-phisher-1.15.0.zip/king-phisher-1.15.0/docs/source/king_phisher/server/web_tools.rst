:mod:`web_tools`
==================

.. module:: king_phisher.server.web_tools
   :synopsis:

This module contains various functions related to the web-serving configuration
of the server.

Functions
---------

.. autofunction:: get_hostnames

.. autofunction:: get_vhost_directories
