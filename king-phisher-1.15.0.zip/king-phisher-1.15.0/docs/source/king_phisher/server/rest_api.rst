:mod:`rest_api`
===============

.. module:: king_phisher.server.rest_api
   :synopsis:

This module provides the functionality exposed by the server application's REST
API.

Data
----

.. autodata:: REST_API_BASE
   :annotation:

Functions
---------

.. autofunction:: generate_token

.. autofunction:: rest_handler
