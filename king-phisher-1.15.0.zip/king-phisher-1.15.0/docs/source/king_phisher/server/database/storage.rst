:mod:`storage`
=======================

.. module:: king_phisher.server.database.storage
   :synopsis:

This module provides functionality to utilize the database for persistent
storage.

Classes
-------

.. autoclass:: KeyValueStorage
   :members:
   :special-members: __init__
   :undoc-members:
