:mod:`database`
===============

.. module:: king_phisher.server.database

.. toctree::
   :maxdepth: 2
   :titlesonly:

   manager.rst
   models.rst
   storage.rst
   validation.rst
