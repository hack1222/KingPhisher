:mod:`fs_utilities`
===================

.. module:: king_phisher.server.fs_utilities
   :synopsis:

This module collects various useful file system utility functions that are used throughout
the application.

Functions
---------

.. autofunction:: access

.. autofunction:: chown
