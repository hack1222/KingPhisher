:mod:`schema`
=============

.. module:: king_phisher.server.graphql.schema
   :synopsis:

Classes
-------

.. autoclass:: Query
   :show-inheritance:

.. autoclass:: Schema
   :show-inheritance:
