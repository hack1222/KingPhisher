:mod:`middlware`
================

.. module:: king_phisher.server.graphql.middleware
   :synopsis:

Classes
-------

.. autoclass:: AuthorizationMiddleware
   :show-inheritance:
   :members:
