:mod:`types`
============

.. module:: king_phisher.server.graphql.types

.. toctree::
   :maxdepth: 2
   :titlesonly:

   database.rst
