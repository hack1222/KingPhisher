:mod:`database`
===============

.. module:: king_phisher.server.graphql.types.database
   :synopsis:

Functions
---------

.. autofunction:: sa_get_relationship

.. autofunction:: sa_object_resolver
