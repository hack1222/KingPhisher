:mod:`smtp_server`
==================

.. module:: king_phisher.smtp_server
   :synopsis:

This module provides a SMTP server that can be used for debugging purposes.

Classes
-------

.. autoclass:: BaseSMTPServer
   :show-inheritance:
   :members: serve_forever
   :special-members: __init__
