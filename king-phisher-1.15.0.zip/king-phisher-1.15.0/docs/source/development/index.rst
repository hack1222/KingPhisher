Development References
======================

.. toctree::
   :maxdepth: 1
   :titlesonly:

   architecture_overview.rst
   modules.rst
   environment_vars.rst
   style_guide.rst
   classifiers.rst
   release_steps.rst
   versions_reference.rst
   windows_build.rst
