The King Phisher Server
=======================

.. toctree::
   :maxdepth: 2
   :titlesonly:

   database/index.rst
   graphql/index.rst

   published_events.rst
   rest_api.rst
   rpc_api.rst
   signals.rst
