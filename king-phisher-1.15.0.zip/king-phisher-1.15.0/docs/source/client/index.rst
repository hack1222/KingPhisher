The King Phisher Client
=======================

.. toctree::
   :maxdepth: 1
   :titlesonly:

   configuration.rst
   completion_data.rst
   gobject_signals.rst
   key_shortcuts.rst
