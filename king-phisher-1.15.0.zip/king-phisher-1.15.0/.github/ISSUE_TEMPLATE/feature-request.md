---
name: Feature Request
about: Suggest an idea for this project

---

# Feature Description
<!-- Describe the feature here that you would like to see added to the project. Does the feature solve a problem and how often do you think it will be used? -->

## Alternatives Solutions
<!-- Describe any alternative solutions you considered and why you came to the conclusion you did regarding the proposed solution. -->

## Example Use Case
<!-- Provide an example of when this feature would be used. -->
