#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  king_phisher/testing.py
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are
#  met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following disclaimer
#    in the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of the project nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#

import functools
import os
import sys
import threading
import time
import urllib

from king_phisher import constants
from king_phisher import find
from king_phisher.client import client_rpc
from king_phisher.server import build
from king_phisher.server import configuration
from king_phisher.server import plugins
from king_phisher.server import rest_api
from king_phisher.server import server
from king_phisher.server.database import manager as db_manager
from king_phisher.server.database import models as db_models

import advancedhttpserver
import smoke_zephyr.utilities

if sys.version_info[0] < 3:
	import httplib
	http = type('http', (), {'client': httplib})
	import urlparse
	urllib.parse = urlparse
	urllib.parse.urlencode = urllib.urlencode
else:
	import http.client
	import urllib.parse  # pylint: disable=ungrouped-imports

__all__ = (
	'TEST_MESSAGE_TEMPLATE',
	'TEST_MESSAGE_TEMPLATE_INLINE_IMAGE',
	'KingPhisherTestCase',
	'KingPhisherServerTestCase'
)

TEST_MESSAGE_TEMPLATE_INLINE_IMAGE = '/path/to/fake/image.png'
"""A string with the path to a file used as an inline image in the :py:data:`.TEST_MESSAGE_TEMPLATE`."""

TEST_MESSAGE_TEMPLATE = """
<html>
<body>
	Hello {{ client.first_name }} {{ client.last_name }},<br />
	<br />
	Lorem ipsum dolor sit amet, inani assueverit duo ei. Exerci eruditi nominavi
	ei eum, vim erant recusabo ex, nostro vocibus minimum no his. Omnesque
	officiis his eu, sensibus consequat per cu. Id modo vidit quo, an has
	detracto intellegat deseruisse. Vis ut novum solet complectitur, ei mucius
	tacimates sit.
	<br />
	Duo veniam epicuri cotidieque an, usu vivendum adolescens ei, eu ius soluta
	minimum voluptua. Eu duo numquam nominavi deterruisset. No pro dico nibh
	luptatum. Ex eos iriure invenire disputando, sint mutat delenit mei ex.
	Mundi similique persequeris vim no, usu at natum philosophia.
	<a href="{{ url.webserver }}">{{ client.company_name }} HR Enroll</a><br />
	<br />
	{{ inline_image('""" + TEST_MESSAGE_TEMPLATE_INLINE_IMAGE + """') }}
	{{ tracking_dot_image_tag }}
</body>
</html>
"""
"""A string representing a message template that can be used for testing."""

def skip_if_offline(test_method):
	"""
	A decorator to skip running tests when the KING_PHISHER_TEST_OFFLINE
	environment variable is set. This allows unit tests which require a internet
	connection to be skipped when network connectivity is known to be inactive.
	"""
	@functools.wraps(test_method)
	def decorated(self, *args, **kwargs):
		if os.environ.get('KING_PHISHER_TEST_OFFLINE'):
			self.skipTest('due to running in offline mode')
		return test_method(self, *args, **kwargs)
	return decorated

def skip_on_travis(test_method):
	"""
	A decorator to skip running a test when executing in the travis-ci environment.
	"""
	@functools.wraps(test_method)
	def decorated(self, *args, **kwargs):
		if os.environ.get('TRAVIS'):
			self.skipTest('due to running in travis-ci environment')
		return test_method(self, *args, **kwargs)
	return decorated

class KingPhisherRequestHandlerTest(server.KingPhisherRequestHandler):
	def on_init(self, *args, **kwargs):
		super(KingPhisherRequestHandlerTest, self).on_init(*args, **kwargs)
		self.rpc_handler_map['^/login$'] = self.rpc_test_login

	def rpc_test_login(self, username, password, otp=None):
		session = db_manager.Session()
		user = session.query(db_models.User).filter_by(name=username).first()
		if not user:
			user = db_models.User(name=username)
		user.last_login = db_models.current_timestamp()
		session.add(user)
		session.commit()
		session_id = self.server.session_manager.put(user)
		session.close()
		return True, constants.ConnectionErrorReason.SUCCESS, session_id

class KingPhisherTestCase(smoke_zephyr.utilities.TestCase):
	"""
	This class provides additional functionality over the built in
	:py:class:`unittest.TestCase` object, including better compatibility for
	methods across Python 2.x and Python 3.x.
	"""
	def assertIsEmpty(self, obj, msg=None):
		"""Test that *obj* is empty as determined by :py:func:`len`."""
		if len(obj):
			self.fail(msg or 'the test object is not empty')

	def assertIsNotEmpty(self, obj, msg=None):
		"""Test that *obj* is not empty as determined by :py:func:`len`."""
		if not len(obj):
			self.fail(msg or 'the test object is empty')

	def assertIsSubclass(self, obj, cls, msg=None):
		"""
		Test that *obj* is a subclass of *cls* (which can be a class or a tuple
		of classes as supported by :py:func:`issubclass`).
		"""
		if not issubclass(obj, cls):
			self.fail(msg or "the test object is not a subclass of '{}'".format(cls.__name__))

	def assertHasAttribute(self, obj, attribute, msg=None):
		"""Test that *obj* has the named *attribute*."""
		if not hasattr(obj, attribute):
			self.fail(msg or "the test object has no attribute '{}'".format(attribute))

class KingPhisherServerTestCase(KingPhisherTestCase):
	"""
	This class can be inherited to automatically set up a King Phisher server
	instance configured in a way to be suitable for testing purposes.
	"""
	def setUp(self):
		find.data_path_append('data/server')
		web_root = os.path.join(os.getcwd(), 'data', 'server', 'king_phisher')
		server_address = {'host': '127.0.0.1', 'port': 0, 'ssl': False}
		config = configuration.Configuration.from_file(find.data_file('server_config.yml'))
		config.set('server.addresses', [server_address])
		config.set('server.database', 'sqlite://')
		config.set('server.geoip.database', os.environ.get('KING_PHISHER_TEST_GEOIP_DB', './GeoLite2-City.mmdb'))
		config.set('server.web_root', web_root)
		config.set('server.rest_api.enabled', True)
		config.set('server.rest_api.token', rest_api.generate_token())
		self.config = config
		self.plugin_manager = plugins.ServerPluginManager(config)
		self.server = build.server_from_config(config, handler_klass=KingPhisherRequestHandlerTest, plugin_manager=self.plugin_manager)
		server_address['port'] = self.server.sub_servers[0].server_port
		self.assertIsInstance(self.server, server.KingPhisherServer)
		self.server_thread = threading.Thread(target=self.server.serve_forever)
		self.server_thread.daemon = True
		self.server_thread.start()
		self.assertTrue(self.server_thread.is_alive())
		self.shutdown_requested = False
		self.rpc = client_rpc.KingPhisherRPCClient(('localhost', server_address['port']))
		self.rpc.login(username='unittest', password='unittest')

	def assertHTTPStatus(self, http_response, status):
		"""
		Check an HTTP response to ensure that the correct HTTP status code is
		specified.

		:param http_response: The response object to check.
		:type http_response: :py:class:`httplib.HTTPResponse`
		:param int status: The status to check for.
		"""
		self.assertIsInstance(http_response, http.client.HTTPResponse)
		error_message = "HTTP Response received status {0} when {1} was expected".format(http_response.status, status)
		self.assertEqual(http_response.status, status, msg=error_message)

	def assertRPCPermissionDenied(self, method, *args, **kwargs):
		"""
		Assert that the specified RPC method fails with a
		:py:exc:`~king_phisher.errors.KingPhisherPermissionError` exception.

		:param method: The RPC method that is to be tested
		"""
		try:
			self.rpc(method, *args, **kwargs)
		except advancedhttpserver.RPCError as error:
			name = error.remote_exception.get('name')
			if name.endswith('.KingPhisherPermissionError'):
				return
			self.fail("the rpc method '{0}' failed".format(method))
		self.fail("the rpc method '{0}' granted permissions".format(method))

	def http_request(self, resource, method='GET', include_id=True, body=None, headers=None):
		"""
		Make an HTTP request to the specified resource on the test server.

		:param str resource: The resource to send the request to.
		:param str method: The HTTP method to use for the request.
		:param bool include_id: Whether to include the the id parameter.
		:param body: The data to include in the body of the request.
		:type body: dict, str
		:param dict headers: The headers to include in the request.
		:return: The servers HTTP response.
		:rtype: :py:class:`httplib.HTTPResponse`
		"""
		if include_id:
			if isinstance(include_id, str):
				id_value = include_id
			else:
				id_value = self.config.get('server.secret_id')
			resource += "{0}id={1}".format('&' if '?' in resource else '?', id_value)
		server_address = self.config.get('server.addresses')[0]
		conn = http.client.HTTPConnection('localhost', server_address['port'])
		request_kwargs = {}
		if isinstance(body, dict):
			body = urllib.parse.urlencode(body)
		if body:
			request_kwargs['body'] = body
		if headers:
			request_kwargs['headers'] = headers
		conn.request(method, resource, **request_kwargs)
		time.sleep(0.025)
		response = conn.getresponse()
		conn.close()
		return response

	def web_root_files(self, limit=None, include_templates=True):
		"""
		A generator object that yields valid files which are contained in the
		web root of the test server instance. This can be used to find resources
		which the server should process as files. The function will fail if
		no files can be found in the web root.

		:param int limit: A limit to the number of files to return.
		:param bool include_templates: Whether or not to include files that might be templates.
		"""
		limit = (limit or float('inf'))
		philes_yielded = 0
		web_root = self.config.get('server.web_root')
		self.assertTrue(os.path.isdir(web_root), msg='The test web root does not exist')
		for web_file_path in smoke_zephyr.utilities.FileWalker(web_root, absolute_path=True, skip_dirs=True):
			web_file_path = os.path.relpath(web_file_path, web_root)
			if not include_templates and os.path.splitext(web_file_path)[1] in ('.txt', '.html'):
				continue
			if philes_yielded < limit:
				yield web_file_path
				philes_yielded += 1
		self.assertGreater(philes_yielded, 0, msg='No files were found in the web root')

	def tearDown(self):
		if not self.shutdown_requested:
			self.assertTrue(self.server_thread.is_alive())
		self.rpc.shutdown()
		self.server.shutdown()
		self.server_thread.join(10.0)
		self.assertFalse(self.server_thread.is_alive())
		del self.server
